<?php

// Subpackage namespace
namespace Wolong\LimitHeartbeat\Core;

// Aliased namespaces
use \Wolong\LimitHeartbeat\Helpers;
use \Wolong\LimitHeartbeat\Heartbeat;

/**
 * Object Factory class
 *
 * @package Limit Heartbeat
 * @subpackage Core
 */
class Factory extends Helpers\Factory {



	/**
	 * Disabler object instance
	 */
	protected function createDisabler() {
		return new Heartbeat\Disabler($this->context());
	}



	/**
	 * Setup object instance
	 */
	protected function createSetup() {
		return new Heartbeat\Setup($this->context());
	}



}