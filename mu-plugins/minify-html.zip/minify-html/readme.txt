=== Minify HTML ===

Contributors: Wolong
Tags: minify, html, css, js, code
Requires at least: 4.4
Tested up to: 5.0
Requires PHP: 7.2
Multisite support: No
Stable tag: 1.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Prefix: MNFHTM

Tactfully minifies HTML output and markup to remove line breaks, whitespace, comments, and other code bloat to cleanup source code and improve speed.

== Description ==

Tactfully minifies HTML output and markup to remove line breaks, whitespace, comments, and other code bloat to cleanup source code and improve speed.

#### Current Features ####

The point of this plugin is to wisely minify HTML without doing "stupid" (unstable) minify methods like bundling external resources and forcing them to load in some messy new file name which is pointless after HTTP/2 anyways.

The minification only happens in the front side, avoiding these contexts:

- Admin area
- During WP installing process
- WP CRON requests
- XMLRPC requests
- WP CLI commands
- Login / register / forgot password pages

In version 1.1.0 we will skip the robots.txt, sitemap, more MIME types, and improve our docs re: HTML tags/functionality. But for now the plugin is working fine and does not cause any errors that we know of.

#### Compatibility ####

This plugin has been designed for use on [SimpleStack](https://simplestack.git.supercluster.io) web servers with PHP 7.2 and MySQL 5.7 to achieve best performance. All of our plugins are meant for single site WordPress installations only; for both performance and usability reasons, we highly recommend avoiding WordPress Multisite for the vast majority of projects.

#### Defined Constants ####

    /* Plugin Meta */
    define('DISABLE_NAG_NOTICES', true);
    
    /* Minify HTML Functions */
    define('MINIFY_HTML', true);
    define('MINIFY_HTML_INLINE_STYLES', true);
    define('MINIFY_HTML_INLINE_STYLES_COMMENTS', true);
    define('MINIFY_HTML_REMOVE_COMMENTS', true);
    define('MINIFY_HTML_REMOVE_CONDITIONALS', true);
    define('MINIFY_HTML_REMOVE_EXTRA_SPACING', true);
    define('MINIFY_HTML_REMOVE_HTML5_SELF_CLOSING', false);
    define('MINIFY_HTML_REMOVE_LINE_BREAKS', true);
    define('MINIFY_HTML_INLINE_SCRIPTS', false);
    define('MINIFY_HTML_INLINE_SCRIPTS_COMMENTS', false);
    define('MINIFY_HTML_UTF8_SUPPORT', true);

#### Special Thanks ####

[Alex Georgiou](https://www.alexgeorgiou.gr), [Automattic](https://automattic.com), [Brad Touesnard](https://bradt.ca), [Daniel Auener](http://www.danielauener.com), [Delicious Brains](https://deliciousbrains.com), [Greg Rickaby](https://gregrickaby.com), [Matt Mullenweg](https://ma.tt), [Mika Epstein](https://halfelf.org), [Mike Garrett](https://mikengarrett.com), [Samuel Wood](http://ottopress.com), [Scott Reilly](http://coffee2code.com), [Jan Dembowski](https://profiles.wordpress.org/jdembowski), [Jeff Starr](https://perishablepress.com), [Jeff Chandler](https://jeffc.me), [Jeff Matson](https://jeffmatson.net), [Jeremy Wagner](https://jeremywagner.me), [John James Jacoby](https://jjj.blog), [Leland Fiegel](https://leland.me), [Luke Cavanagh](https://github.com/lukecav), [Mike Jolley](https://mikejolley.com), [Pau Iglesias](https://pauiglesias.com), [Paul Irish](https://www.paulirish.com), [Rahul Bansal](https://profiles.wordpress.org/rahul286), [Roots](https://roots.io), [rtCamp](https://rtcamp.com), [Ryan Hellyer](https://geek.hellyer.kiwi), [WP Chat](https://wpchat.com), [WP Tavern](https://wptavern.com)

#### Our Philosophy ####

> "Decisions, not options." -- WordPress.org

> "Everything should be made as simple as possible, but no simpler." -- Albert Einstein

> "Write programs that do one thing and do it well... write programs to work together." -- Doug McIlroy

> "The innovation that this industry talks about so much is bullshit. Anybody can innovate... 99% of it is 'Get the work done.' The real work is in the details." -- Linus Torvalds

#### Search Keywords ####

n/a

== Frequently Asked Questions ==

= How can I change this plugin's settings? =

None use the defined constants.

= Can you explain about the defined constants? =

MINIFY_HTML
Enables the plugin functionality
Enabled by default

MINIFY_HTML_UTF8_SUPPORT
UTF8 support for regular expression operations
Enabled by default

MINIFY_HTML_REMOVE_EXTRA_SPACING
Replace extra spaces in HTML and espaces between tags (except in styles, javascript code, and the content of textarea and pre tags)
Enabled by default

MINIFY_HTML_REMOVE_LINE_BREAKS
Removes line breaks in HTML (except in styles, javascript code, and the content of textarea and pre tags)
Enabled by default

MINIFY_HTML_REMOVE_COMMENTS
Removes HTML comments (including HTML comments inside the pre tag but leaving the textarea comments)
It does not remove conditionals comments like <!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
Enabled by default

MINIFY_HTML_INLINE_STYLES
Minify inline styles between <style></style> tags removing extra espaces and line breaks
Enabled by default

MINIFY_HTML_INLINE_STYLES_COMMENTS
Removes inline styles comments /* .. */
Only works if MINIFY_HTML_INLINE_STYLES is enabled
Enabled by default

MINIFY_HTML_INLINE_SCRIPTS
Minify inline scripts code between <script></script> tags, removing extra espaces and line breaks
Disabled by default

MINIFY_HTML_INLINE_SCRIPTS_COMMENTS
Remove inline scripts comments /* .. */ and //
Only works if MINIFY_HTML_INLINE_SCRIPTS is enabled
Disabled by default

MINIFY_HTML_REMOVE_CONDITIONALS
Remove conditional tags like <!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
Enabled by default

MINIFY_HTML_REMOVE_HTML5_SELF_CLOSING
Removes self-closing markup only for HTML5 documents, e.g. <meta charset="UTF-8" /> => <meta charset="UTF-8">
Determines if it is an HTML5 document when it starts with "<!doctype html>"
Disabled by default

== Changelog ==

= 1.0.1 =
* fixed bug in `REMOVE_EXTRA_SPACING` that was removing spaces before/after inline HTML tags

= 1.0.0 =
* initial release
* tested with PHP 7.0
* tested with PHP 7.1
* tested with PHP 7.2
