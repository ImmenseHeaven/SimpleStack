=== Disable Emojis ===

Contributors: Wolong
Tags: disable, remove, emojis, emoticons, smileys
Requires at least: 4.4
Tested up to: 5.0
Requires PHP: 7.0
Multisite support: No
Stable tag: 1.2.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Prefix: DSBEMJ

Completely disables both the old and new versions of WordPress emojis, removes the corresponding javascript calls, and improves page loading times.

== Description ==

Completely disables both the old and new versions of WordPress emojis, removes the corresponding javascript calls, and improves page loading times.

#### Current Features ####

Unlike some other similar plugins, this plugin forces the "convert emoticons" option in WordPress settings to be unregistered directly using a hook. If users deactivate this plugin, that setting will return to previous value (whatever it was set to prior to activating this plugin) so it's very conflict free.

ALL types of emojis and emoticons (smileys) are disabled with this plugin, including the old version and new versions, along with the javascript calls. This creates lighter source code for your site, helps with loading speed, and can also make pages render faster since they don't need to load emojis too.

#### Compatibility ####

This plugin has been designed for use on [SimpleStack](https://simplestack.git.supercluster.io) web servers with PHP 7.2 and MySQL 5.7 to achieve best performance. All of our plugins are meant for single site WordPress installations only; for both performance and usability reasons, we highly recommend avoiding WordPress Multisite for the vast majority of projects.

#### Defined Constants ####

    /* Plugin Meta */
    define('DISABLE_NAG_NOTICES', true);

== Changelog ==

= 1.2.0 =
* tested with WP 5.0

= 1.1.2 =
* updated plugin meta

= 1.1.1 =
* added warning for Multisite installations
* updated recommended plugins

= 1.1.0 =
* plugin entirely re-written with PHP namespaces
* plugin uses object-oriented code
* added more "disable" filters
* support for `DISABLE_NAG_NOTICES`
* removed improperly credited Ryan Hellyer code snippet
* (apologies to Ryan Hellyer)
* updated plugin meta

= 1.0.5 =
* tested with WP 4.9
* optimized plugin code
* updated recommended plugins
* updated plugin meta

= 1.0.4 =
* optimized plugin code
* added rating request notice
* updated recommended plugins

= 1.0.3 =
* optimized plugin code
* updated recommended plugins

= 1.0.2 =
* added recommended plugins notice

= 1.0.1 =
* updated plugin meta

= 1.0.0 =
* initial release
