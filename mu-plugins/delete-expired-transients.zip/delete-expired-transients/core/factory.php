<?php

// Subpackage namespace
namespace Wolong\DeleteExpiredTransients\Core;

// Aliased namespaces
use \Wolong\DeleteExpiredTransients\Transients;
use \Wolong\DeleteExpiredTransients\Helpers;

/**
 * Object Factory class
 *
 * @package Delete Expired Transients
 * @subpackage Core
 */
class Factory extends Helpers\Factory {



	/**
	 * Actions object
	 */
	protected function createCron() {
		return new Transients\Cron($this, $this->plugin);
	}


	/**
	 * Filters object
	 */
	protected function createTransients() {
		return new Transients\Transients;
	}



}