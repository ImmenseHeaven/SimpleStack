=== Disable XML-RPC ===

Contributors: Wolong
Tags: disable, xml-rpc, xmlrpc, pingbacks, trackbacks
Requires at least: 4.4
Tested up to: 5.0
Requires PHP: 7.0
Multisite support: No
Stable tag: 1.1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Prefix: DSBXML

Completely disables all XML-RPC related functions in WordPress including pingbacks and trackbacks, and helps prevent attacks on the xmlrpc.php file.

== Description ==

Completely disables all XML-RPC related functions in WordPress including pingbacks and trackbacks, and helps prevent attacks on the xmlrpc.php file.

#### Current Features ####

Does not affect the database whatsoever, nor change settings on existing posts/pages. This plugin only affects the main Discussion settings while disabling XML-RPC API functions. If you wish to "clean up" all posts and pages in your database e.g. turn off all their pingbacks and trackbacks or delete the old ones, please use a different plugin for that.

Lastly, it attempts to generate a 403 Denied error for requests to the `/xmlrpc.php` URL, but does not affect that file or your server in any way.

#### Compatibility ####

This plugin has been designed for use on [SimpleStack](https://simplestack.git.supercluster.io) web servers with PHP 7.2 and MySQL 5.7 to achieve best performance. All of our plugins are meant for single site WordPress installations only; for both performance and usability reasons, we highly recommend avoiding WordPress Multisite for the vast majority of projects.

#### Defined Constants ####

    /* Plugin Meta */
    define('DISABLE_NAG_NOTICES', true);

== Changelog ==

= 1.1.1 =
* updated recommended plugins

= 1.1.0 =
* tested with WP 5.0

= 1.0.8 =
* updated recommended plugins

= 1.0.7 =
* optimized plugin code
* added warning for Multisite installations
* updated recommended plugins
* updated plugin meta

= 1.0.6 =
* updated recommended plugins

= 1.0.5 =
* better support for `DISABLE_NAG_NOTICES`

= 1.0.4 =
* tested with WP 4.9
* updated plugin meta
* partial support for `DISABLE_NAG_NOTICES`

= 1.0.3 =
* optimized plugin code
* updated recommended plugins
* added rating request notice

= 1.0.2 =
* optimized plugin code
* updated recommended plugins

= 1.0.1 =
* added recommended plugins notice

= 1.0.0 =
* initial release
